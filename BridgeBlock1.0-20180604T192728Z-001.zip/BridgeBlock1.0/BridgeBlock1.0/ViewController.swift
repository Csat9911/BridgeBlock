//
//  ViewController.swift
//  BridgeBlock1.0
//
//  Created by admin mcadmin on 2/1/18.
//  Copyright © 2018 AppTeam. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import FirebaseDatabase


class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    //Opeing Action
    @IBOutlet var background: UIImageView!
    
    @IBOutlet var pickerView: UIPickerView!
    var pickerData: [String] = [String]()
    let bridgeSpots = ["Route35 Bridge", "Point Pleasant Beach Train Station", "Bayhead Train Station", "Beaver Dam Bridge", "Lovelandtown Bridge", "Route88 Bridge"]
    
    //mapView variables
    @IBOutlet var mapView: MKMapView!
    let locationMan = CLLocationManager()
    var rt35Border = MKCircle(center: CLLocationCoordinate2DMake(40.10299268225063, -74.05259487344972), radius: 600)
    var ptBeachBorder = MKCircle(center: CLLocationCoordinate2DMake(40.09209376952605, -74.04821750833742), radius: 600)
    var bayHeadBorder = MKCircle(center: CLLocationCoordinate2DMake(40.07679295347464, -74.04607174112556), radius: 600)
    var rt88Border = MKCircle(center: CLLocationCoordinate2DMake(40.083506834294525, -74.06671294969948), radius: 600)
    var lovelandBorder = MKCircle(center: CLLocationCoordinate2DMake(40.071837949595604, -74.06008308909105), radius: 600)
    var beaverBorder = MKCircle(center: CLLocationCoordinate2DMake(40.05987361023375, -74.07221419645117), radius: 600)
    
    
    //Database variabels
    var ref: DatabaseReference!
    var temp35 = true
    var temppt = true
    var tempbh = true
    var tempbd = true
    var temp88 = true
    var templl = true
    
    //Timer Variables
    var timer = Timer()
    
    var key = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.isHidden = false
    
        //Starts Location and dots on map 
        
        
        locationMan.requestAlwaysAuthorization()
        locationMan.startUpdatingLocation()
        mapView.removeOverlays(self.mapView.overlays)
        
        mapView.add(self.rt35Border)
        mapView.add(self.ptBeachBorder)
        mapView.add(self.bayHeadBorder)
        mapView.add(self.beaverBorder)
        mapView.add(self.lovelandBorder)
        mapView.add(self.rt88Border)
        
        self.pickerView.delegate = self
        self.pickerView.dataSource = self
        
        pickerData = ["Route35 Bridge", "Point Pleasant Beach Train Station", "Bayhead Train Station", "Beaver Dam Bridge", "Lovelandtown Bridge", "Route88 Bridge"]
        
        scheduledTimerWithTimeInterval()
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return bridgeSpots[row]
        
        
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return bridgeSpots.count
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        var regionCoord = CLLocationCoordinate2DMake(40.083506834294525, -74.06671294969948)
        
        if (pickerData[row] == "Route35 Bridge") {
            regionCoord = CLLocationCoordinate2DMake(40.10299268225063, -74.05259487344972)
        }
        if (pickerData[row] == "Point Pleasant Beach Train Station") {
            regionCoord = CLLocationCoordinate2DMake(40.09209376952605, -74.04821750833742)
        }
        if (pickerData[row] == "Bayhead Train Station") {
            regionCoord = CLLocationCoordinate2DMake(40.07679295347464, -74.04607174112556)
        }
        if (pickerData[row] == "Beaver Dam Bridge") {
            regionCoord = CLLocationCoordinate2DMake(40.05987361023375, -74.07221419645117)
        }
        if (pickerData[row] == "Lovelandtown Bridge") {
            regionCoord = CLLocationCoordinate2DMake(40.071837949595604, -74.06008308909105)
        }
        
        //setting region
        let region = MKCoordinateRegionMakeWithDistance(regionCoord, 2000, 2000)
        mapView.setRegion(region, animated: true)
        
    }
    
    
    
    
    
    //Function that starts timer
    func scheduledTimerWithTimeInterval() {
        
        timer = Timer.scheduledTimer(timeInterval: 8, target: self, selector: #selector(self.updateCounting), userInfo: nil, repeats: true)
        
    }
    
    
    
    
    
    //Function called every 8 seconds
    func updateCounting() {
        
        
        ref = Database.database().reference()
        
        
        ref?.observe(.value, with:
            {(snapshot) in
                if let getData = snapshot.value as? [String:Any] {
                    
                    let state = (getData["Route35BridgeState"] as? String)!
                    
                    if (state == "open") {
                        self.temp35 = true
                    }
                    else {
                        self.temp35 = false
                    }
                }
        })
        
        key = 0
        
        mapView.add(self.rt35Border)
        
        
        ref?.observe(.value, with:
            {(snapshot) in
                if let getData = snapshot.value as? [String:Any] {
                
                    let state = (getData["PointBeachStationState"] as? String)!
                
                    if (state == "open") {
                        self.temppt = true
                    }
                    else {
                        self.temppt = false
                    }
                }
        })
        
        key = 1
        
        mapView.add(self.ptBeachBorder)
        
        ref?.observe(.value, with:
            {(snapshot) in
                if let getData = snapshot.value as? [String:Any] {
                
                    let state = (getData["BayHeadStationState"] as? String)!
            
                    if (state == "open") {
                        self.tempbh = true
                    }
                    else {
                        self.tempbh = false
                    }
                }
        })
        
        key = 2
        
        mapView.add(self.bayHeadBorder)
        
        ref?.observe(.value, with:
            {(snapshot) in
                if let getData = snapshot.value as? [String:Any] {
                
                    let state = (getData["Route88BridgeState"] as? String)!
                
                    if (state == "open") {
                        self.temp88 = true
                    }
                    else {
                        self.temp88 = false
                    }
                }
        })
        
        key = 3
        
        mapView.add(self.rt88Border)
        
        ref?.observe(.value, with:
            {(snapshot) in
                if let getData = snapshot.value as? [String:Any] {
                    
                    let state = (getData["LovelandtownBridgeState"] as? String)!
            
                    if (state == "open") {
                        self.templl = true
                    }
                    else {
                        self.templl = false
                    }
                }
        })
        
        key = 4
        
        mapView.add(self.lovelandBorder)
        
        ref?.observe(.value, with:
            {(snapshot) in
                if let getData = snapshot.value as? [String:Any] {
                   
                    let state = (getData["BeaverDamBridgeState"] as? String)!
                
                    if (state == "open") {
                        self.tempbd = true
                    }
                    else {
                        self.tempbd = false
                    }
                }
        })
        
        key = 5
        
        mapView.add(self.beaverBorder)

        
        
    }
    
        
    
        
    }
    



extension ViewController: CLLocationManagerDelegate {

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        locationMan.stopUpdatingLocation()
        mapView.showsUserLocation = true
        
    }
}


extension ViewController: MKMapViewDelegate {

    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        
        guard let circleOverlay = overlay as? MKCircle else {

            return MKOverlayRenderer()
        }
        
        if (key == 0) {
        if (self.temp35 == true) {
            
        let circleRenderer = MKCircleRenderer(circle: circleOverlay)
        circleRenderer.strokeColor = .green
        circleRenderer.fillColor = .green
        circleRenderer.alpha = 0.6
        return circleRenderer
            
        }
        
        else {
            let circleRenderer = MKCircleRenderer(circle: circleOverlay)
            circleRenderer.strokeColor = .red
            circleRenderer.fillColor = .red
            circleRenderer.alpha = 0.6
            return circleRenderer        }
            
        }
        
        if (key == 1) {
            
            if (temppt == true) {
                let circleRenderer = MKCircleRenderer(circle: circleOverlay)
                circleRenderer.strokeColor = .green
                circleRenderer.fillColor = .green
                circleRenderer.alpha = 0.6
                return circleRenderer
            }
                
            else {
                let circleRenderer = MKCircleRenderer(circle: circleOverlay)
                circleRenderer.strokeColor = .red
                circleRenderer.fillColor = .red
                circleRenderer.alpha = 0.6
                return circleRenderer        }
            
            
        }
        
        if (key == 2) {
            
            if (tempbh == true) {
                let circleRenderer = MKCircleRenderer(circle: circleOverlay)
                circleRenderer.strokeColor = .green
                circleRenderer.fillColor = .green
                circleRenderer.alpha = 0.6
                return circleRenderer
            }
                
            else {
                let circleRenderer = MKCircleRenderer(circle: circleOverlay)
                circleRenderer.strokeColor = .red
                circleRenderer.fillColor = .red
                circleRenderer.alpha = 0.6
                return circleRenderer        }
            
            
        }
        if (key == 3) {
            
            if (temp88 == true) {
                let circleRenderer = MKCircleRenderer(circle: circleOverlay)
                circleRenderer.strokeColor = .green
                circleRenderer.fillColor = .green
                circleRenderer.alpha = 0.6
                return circleRenderer
            }
                
            else {
                let circleRenderer = MKCircleRenderer(circle: circleOverlay)
                circleRenderer.strokeColor = .red
                circleRenderer.fillColor = .red
                circleRenderer.alpha = 0.6
                return circleRenderer        }
            
            
        }
        if (key == 4) {
            
            if (templl == true) {
                let circleRenderer = MKCircleRenderer(circle: circleOverlay)
                circleRenderer.strokeColor = .green
                circleRenderer.fillColor = .green
                circleRenderer.alpha = 0.6
                return circleRenderer
            }
                
            else {
                let circleRenderer = MKCircleRenderer(circle: circleOverlay)
                circleRenderer.strokeColor = .red
                circleRenderer.fillColor = .red
                circleRenderer.alpha = 0.6
                return circleRenderer        }
            
            
        }
        if (key == 5) {
            
            if (tempbd == true) {
                let circleRenderer = MKCircleRenderer(circle: circleOverlay)
                circleRenderer.strokeColor = .green
                circleRenderer.fillColor = .green
                circleRenderer.alpha = 0.6
                return circleRenderer
            }
                
            else {
                let circleRenderer = MKCircleRenderer(circle: circleOverlay)
                circleRenderer.strokeColor = .red
                circleRenderer.fillColor = .red
                circleRenderer.alpha = 0.6
                return circleRenderer        }
            
            
        }

        let circleRenderer = MKCircleRenderer(circle: circleOverlay)
        return circleRenderer

    }
    }




