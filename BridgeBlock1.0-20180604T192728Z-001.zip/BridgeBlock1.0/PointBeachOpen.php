<?php  

	$FIREBASE = "https://bridge-block.firebaseio.com/"; 
	$NODE_DELETE = "PointBeachStationState.json"; 
	$NODE_GET = "PointBeachStationState.json"; 
	$NODE_PATCH = ".json"; 
	$NODE_PUT = "PointBeachStationState.json"; 

	$data = "open"; 

	$data = array( 
			"PointBeachStationState" => "open" 
	); 

	$json = json_encode($data); 

	$curl = curl_init();

	curl_setopt( $curl, CURLOPT_URL, $FIREBASE . $NODE_PATCH);
	curl_setopt( $curl, CURLOPT_CUSTOMREQUEST, "PATCH"); 
	curl_setopt( $curl, CURLOPT_POSTFIELDS, $json);  

	curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true); 

	$response = curl_exec( $curl ); 
	curl_close( $curl );   

	echo $respnse . "\n"; 


?> 