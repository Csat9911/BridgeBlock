<?php 
	echo "Bridge Block PHP Page <br>"; 

	$consumerKey    = '3UT7Yxlv95weUV2HPOANheJbG';
	$consumerSecret = 'jdMzNb95yyrdtEuh2dCCP5dv0JzJSl4vQjAaI9ICarLPii1WXT';
	$oAuthToken     = '948629728650498049-SMhysjiXviQlPbei4nrV3BXsURV6bCW';
	$oAuthSecret    = 'LszP0vsD0SEjdnzXyPNYrlWX5Lx56uUGEbeYtK9kqvuVf'; 

	
	require_once('twitteroauth.php');
	$tweet = new TwitterOAuth($consumerKey, $consumerSecret, $oAuthToken, $oAuthSecret);  
	
	$tz = 'US/Eastern';  
	$timestamp = time(); 
	$dt = new DateTime("now", new DateTimeZone($tz));
	$dt->setTimestamp($timestamp);

	//Stores the Current Date in Variables 
	$currentMonth = $dt->format('m');  
	$currentDay = $dt->format('N'); 
	$currentHour = $dt->format('H');  
	$currentMinute = $dt->format('i'); 
	
	echo $currentMonth; 
	echo "<br>"; 
	echo $currentDay; 
	echo "<br>"; 
	echo $currentHour; 
	echo "<br>"; 
	echo $currentMinute; 
	echo "<br>"; 

	$finalCheck35 = true; 
	$finalCheckPoint = true;
	
	// New Tweet messages for the different Bridges and stations 
	$tweetMessageRt35 = "The Route 35 Bridge is going up"; 
	$tweetMessageBayHead = 'The Bay Head train will be entering Station in 10 minutes'; 
	$tweetMessagePtBeach = 'The Point Pleasant Beach train will be entering station in 10 minutes ';

	//Checks When the Route 35 Bridge Goes Up 
	
	if ( ($currentMonth >= 1) && ($currentMonth <= 12) ) {   
	
		if( ($currentDay >= 1) && ($currentDay <= 15) ) {  
		
			if((($currentHour >= 10) && ($currentHour <= 19)) && ($currentMinute == 34)) { 
			
				echo "The Route 35 Bridge is going up <br>"; 
				//Sends out a Tweet that the Route 35 Bridge is up
				$tweet->post('statuses/update', array('status' => $tweetMessageRt35)); 
				echo "Tweet was Sent <br>";   
				
				//send private message
				$tweet->post('direct_messages/new', array('screen_name' => 'block_bridge', 'text' => 'Route 35 Bridge Notification went out'));                                                    
				closeBridge();
				$finalCheck35 = false; 

				} 
			} 
			
		if ($currentDay == 5) {  
		
			if ( (($currentHour>= 12) && ($currentHour <= 19)) && ($currentMinute == 45) ) {   
			
				echo "The Route 35 Bridge is going up <br>"; 
				
				//Sends out a Tweet that the Route 35 Bridge is up
				$tweet->post('statuses/update', array('status' => $tweetMessageRt35)); 
				echo "Tweet was Sent <br>";   
				
				//send private message
				$tweet->post('direct_messages/new', array('screen_name' => 'block_bridge', 'text' => 'Route 35 Bridge Notification went out'));
				closeBridge(); 
				$finalCheck35 = false; 
			
				} 
		
			}   
			
		if ( (($currentHour >= 8) && ($currentHour <= 20)) && ($currentMinute == 45) ) {  
		
				echo "The Route 35 Bridge is going up <br>"; 
				
				//Sends out a Tweet that the Route 35 Bridge is up
				$tweet->post('statuses/update', array('status' => $tweetMessageRt35)); 
				echo "Tweet was Sent <br>";   
				
				//send private message
				$tweet->post('direct_messages/new', array('screen_name' => 'block_bridge', 'text' => 'Route 35 Bridge Notification went out'));
				closeBridge();  
				$finalCheck35 = false;
			}
		
		} 
		
		echo "hi<br>";
		//Checks When Point Beach Station is in use 
	if($currentDay!=6 && $currentDay!=7){
		if((($currentHour==7) && ($currentMinute==46)) || (($currentHour==9) && ($currentMinute==07)) || (($currentHour==9) && ($currentMinute==49)) || (($currentHour==11) && ($currentMinute==51)) || (($currentHour==12) && ($currentMinute==49)) || (($currentHour==14) && ($currentMinute==52)) || (($currentHour==16) && ($currentMinute==17)) || (($currentHour==17) && ($currentMinute==38)) || (($currentHour==18) && ($currentMinute==26)) || (($currentHour==18) && ($currentMinute==57)) || (($currentHour==19) && ($currentMinute==32)) || (($currentHour==20) && ($currentMinute==09)) || (($currentHour==21) && ($currentMinute==05)) || (($currentHour==22) && ($currentMinute==22)) || (($currentHour==24) && ($currentMinute==30)) || (($currentHour==1) && ($currentMinute==24))){
			$tweet->post('statuses/update', array('status' => $tweetMessagePtBeach.(" ").($currentHour).(":").($currentMinute)));
			echo "Tweer was sent<br>"; 
			closePointBeach(); 
			$finalCheckPoint = false;
			
		}
	}
			
	if ($currentDay == 6 || $currentDay == 7){
		if((($currentHour == 5) && ($currentMinute==15)) || (($currentHour == 7) && ($currentMinute==15)) || (($currentHour == 9) && ($currentMinute==15)) || (($currentHour == 11) && ($currentMinute==15)) || (($currentHour == 13) && ($currentMinute==15)) || (($currentHour == 15) && ($currentMinute==22)) || (($currentHour == 17) && ($currentMinute==15)) || (($currentHour == 18) && ($currentMinute==13)) || (($currentHour == 20) && ($currentMinute==15)) || (($currentHour == 21) && ($currentMinute==13)) || (($currentHour == 23) && ($currentMinute==29))){
			$tweet->post('statuses/update', array('status' => $tweetMessagePtBeach.($currentHour).($currentMinute)));
			echo "Tweet was sent<br>"; 	 
			closePointBeach(); 
			$finalCheckPoint = false;
		}
	}	

	//return to open checks   
	if ($finalCheck35 == true) { 
		openRoute35Bridge();
	}  
	if ($finalCheckPoint == true) { 
		openPointBeach();
	}

	//dataBase Change functions
	function closeRoute35Bridge() { 
		include('Route35Close.php');
	}   
	function openRoute35Bridge() {  
		include ('Route35Open.php');
	} 
	function closePointBeach(){ 
		include ('PointBeachClose.php');
	} 
	function openPointBeach(){ 
		include ('PointBeachOpen.php');
	}
		//Direct Message Check
		echo "end of code <br>";
		



   		   
   
	
	
?> 

