<?php  

	$FIREBASE = "https://bridge-block.firebaseio.com/"; 
	$NODE_DELETE = "Route35BridgeState.json"; 
	$NODE_GET = "Route35BridgeState.json"; 
	$NODE_PATCH = ".json"; 
	$NODE_PUT = "Route35BridgeState.json"; 

	$data = "open"; 

	$data = array( 
			"Route35BridgeState" => "open" 
	); 

	$json = json_encode($data); 

	$curl = curl_init();

	curl_setopt( $curl, CURLOPT_URL, $FIREBASE . $NODE_PATCH);
	curl_setopt( $curl, CURLOPT_CUSTOMREQUEST, "PATCH"); 
	curl_setopt( $curl, CURLOPT_POSTFIELDS, $json);  

	curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true); 

	$response = curl_exec( $curl ); 
	curl_close( $curl );   

	echo $respnse . "\n"; 


?> 
